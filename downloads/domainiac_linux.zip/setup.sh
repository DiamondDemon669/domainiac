echo Welcome to domainiac installer
echo you wont have to do much from here
echo installing program ...
crontab -l | { cat; echo "@reboot $PWD/wsgi"; } | crontab -
echo Running program ...
$PWD/wsgi
echo Installation complete!
